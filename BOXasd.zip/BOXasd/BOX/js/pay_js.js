var cids = "";

// 이름 눌렀을 때 박스 팝업
function doDisplay(){
    var con1 = document.getElementById("MyInfo");
    var con2 = document.getElementById("MyInfo_line");
    if(con1.style.display=='none'){
        con1.style.display = 'block';
        con2.style.display = 'block';
    }else{
        con1.style.display = 'none';
        con2.style.display = 'none';
    }
}

function My_cart_info(cartid) {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE) {
        var result = JSON.parse(xhr.responseText);
            if (xhr.status === 200 || xhr.status === 201) 
            {  
                //sucess
                for(let a = 0; a < result.length; a++)
                {
                    //console.log(cartid + "- " + result[a]);

                    var item = document.createElement("span");
                    item.setAttribute("class", "cart_font");
                    item.innerText = "[" + result[a].product_brand + "] " + result[a].product_name + "\n";
                    document.getElementById("infoid" + cartid).appendChild(item);
                }
                
                
            } else {

                //error
            }
        }
    }

    xhr.open("POST", "http://13.209.181.48:3000/cart/item");
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("_id=" + cartid);
}

function My_cart() {
    
    let cart = [];

    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE) {
        var result = JSON.parse(xhr.responseText);
            if (xhr.status === 200 || xhr.status === 201) 
            {  
                //sucess
                
                
        
                for(let a = 0; a < result.length; a++)
                {
                    console.log(result[a]);

                    cart[a] = document.createElement("div");
                    cart[a].setAttribute("class", "cart");
                    sessionStorage.setItem('cart'+a, result[a].cart_id);
                    
                    var thumbnail_case = document.createElement("div");
                    thumbnail_case.setAttribute("class", "thumbnail_case");
                    var thumbnail = document.createElement("img");
                    thumbnail.setAttribute("class", "thumbnail");
                    thumbnail.src = result[a].cart_thumbnail;
                    thumbnail_case.appendChild(thumbnail);
                    cart[a].appendChild(thumbnail_case);

                    var info = document.createElement("div");
                    info.id = "infoid" + result[a].cart_id;
                    info.style.marginTop = "25px";

                    var buildabox = document.createElement("span");
                    buildabox.style.fontSize = "16px";
                    buildabox.style.fontWeight = "bold";
                    buildabox.innerText = "Build a Box\n";
                    info.appendChild(buildabox);
                    var subname = document.createElement("span");
                    subname.setAttribute("class", "cart_font");
                    subname.innerText = result[a].cart_subname + "\n\n";
                    info.appendChild(subname);

                    var cardtype = document.createElement("span");
                    cardtype.style.fontSize = "16px";
                    cardtype.style.fontWeight = "bold";
                    cardtype.innerText = result[a].cart_cardtype + "\n";
                    info.appendChild(cardtype);

                    var msg = document.createElement("span");
                    msg.style.fontSize = "14px";
                    msg.style.fontWeight = "bold";
                    msg.innerText = "카드 내용 / ";
                    info.appendChild(msg);

                    var cardmsg = document.createElement("span");
                    cardmsg.setAttribute("class", "cart_font");
                    cardmsg.innerText = result[a].cart_cardmsg + "\n\n";
                    info.appendChild(cardmsg);

                    var present = document.createElement("span");
                    present.style.fontSize = "16px";
                    present.style.fontWeight = "bold";
                    present.innerText = "담은 선물\n";
                    info.appendChild(present);

                    My_cart_info(result[a].cart_id);
                    cart[a].appendChild(info);


                    var num = document.createElement("div");
                    num.style.textAlign = "right";
                    num.style.marginTop = "43px";
                    var cartnum = document.createElement("span");
                    cartnum.style.fontSize = "16px"
                    cartnum.style.fontFamily = "Noto Sans";
                    cartnum.innerText = result[a].cart_num + "개";
                    num.appendChild(cartnum);
                    cart[a].appendChild(num);

                    var price_case = document.createElement("div");
                    price_case.style.textAlign = "right";
                    price_case.style.marginTop = "43px";
                    var price = document.createElement("span");
                    price.style.fontSize = "16px"
                    price.style.fontFamily = "Noto Sans";
                    price.innerText = result[a].cart_tp + "원";
                    price_case.appendChild(price);
                    cart[a].appendChild(price_case);

                    var delivery_case = document.createElement("div");
                    delivery_case.style.textAlign = "right";
                    delivery_case.style.marginTop = "43px";
                    var delivery = document.createElement("span");
                    delivery.style.fontSize = "16px"
                    delivery.style.fontFamily = "Noto Sans";
                    delivery.innerText = "3,000원";
                    delivery_case.appendChild(delivery);
                    cart[a].appendChild(delivery_case);


                    document.getElementById("layout1_1").appendChild(cart[a]);
                }
                
                
            } else {

                //error
            }
        }
    }

    xhr.open("POST", "http://13.209.181.48:3000/cart/list");
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("_id=" + sessionStorage.getItem('id_con'));
}



// 상품 전체 가격
function TotalPrice() {
    let cart_tp = 0 ;
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE) {
        var result = JSON.parse(xhr.responseText);
            if (xhr.status === 200 || xhr.status === 201) 
            {  
                //sucess 
                for(let a = 0; a < result.length; a++)
                {
                    const num =  Number(result[a].cart_tp.replace(",",""));
                    cart_tp = cart_tp + num;
                    cids += ","+result[a].cart_id
                }
                
                let TotalPrice = document.querySelectorAll("#TotalPrice");
                for(let b = 0; b < TotalPrice.length; b++)
                {
                    TotalPrice[b].innerText = cart_tp;
                }
            } else {

                //error
            }
        }
    }
    xhr.open("POST", "http://13.209.181.48:3000/cart/list");
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("_id=" + sessionStorage.getItem('id_con'));
}

// 배송비
function DeliveryFee() {
    let deliveryfee = 0 ;
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE) {
        var result = JSON.parse(xhr.responseText);
            if (xhr.status === 200 || xhr.status === 201) 
            {  
                //sucess 
                for(let a = 0; a < result.length; a++)
                {
                    //const num =  Number(result[a].cart_tp.replace(",",""));
                    //cart_tp = cart_tp + num;
                    //cids += ","+result[a].cart_id
                    deliveryfee += 3000;
                }
                
                let DeliveryFee = document.querySelectorAll("#DeliveryFee");
                for(let b = 0; b < DeliveryFee.length; b++)
                {
                    DeliveryFee[b].innerText = deliveryfee;
                }
            } else {

                //error
            }
        }
    }
    xhr.open("POST", "http://13.209.181.48:3000/cart/list");
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("_id=" + sessionStorage.getItem('id_con'));
}

// 배송비 + 상품 전체 가격
function RealTotalPrice() {
    let realtotalprice = 0 ;
    let deliveryfee = 0;
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE) {
        var result = JSON.parse(xhr.responseText);
            if (xhr.status === 200 || xhr.status === 201) 
            {  
                //sucess 
                for(let a = 0; a < result.length; a++)
                {
                    const num =  Number(result[a].cart_tp.replace(",",""));
                    realtotalprice = realtotalprice + num;
                    deliveryfee += 3000;
                }
                
                realtotalprice = realtotalprice + deliveryfee;

                let RealTotalPrice = document.querySelectorAll("#RealTotalPrice")
                for(let b = 0; b < RealTotalPrice.length; b++)
                {
                    RealTotalPrice[b].innerText = realtotalprice + "원";
                }
            } else {

                //error
            }
        }
    }
    xhr.open("POST", "http://13.209.181.48:3000/cart/list");
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("_id=" + sessionStorage.getItem('id_con'));
}


// 주문자 정보와 동일합니다.
function SameSame() {
   let user_name = document.getElementById("user_name");
   let user_postcode = document.getElementById("user_postcode");
   let user_address =document.getElementById("user_address");
   let user_subaddress = document.getElementById("user_subaddress");
   let user_phone1 = document.getElementById("user_phone1");
   let user_phone2 = document.getElementById("user_phone2");
   let user_phone3 = document.getElementById("user_phone3");

   document.querySelector("#to_name").value = user_name.value;
   document.querySelector("#to_postcode").value = user_postcode.value;
   document.querySelector("#to_address").value = user_address.value;
   document.querySelector("#to_subaddress").value = user_subaddress.value;
   document.querySelector("#to_phone1").value = user_phone1.value;
   document.querySelector("#to_phone2").value = user_phone2.value;
   document.querySelector("#to_phone3").value = user_phone3.value;
}

// 신용카드or무통장 선택 -> 입금자명&현금영수증 신청 버튼 팝업
function CardCash() {
    let cardcash = document.getElementsByName("cardcash");
    let cardcash_cash = document.getElementById("cardcash_cash");
    let receipt = document.getElementById("receipt").checked;
    var type = null;

    for(let a = 0; a < cardcash.length; a++){
        if(cardcash[a].checked == true){
            type = cardcash[a].value;
        }
    }

    if(type == "cash") {
        cardcash_cash.style.display = "block";
    }
    else {
        cardcash_cash.style.display = "none";
        document.getElementById("receipt").checked = false;
    }
}

// 소득공제&지출증빙 팝업
function Receipt_box() {
    let receipt_box = document.getElementById("receipt_box");
    let receipt = document.getElementById("receipt").checked;

    if(receipt == true){
        receipt_box.style.display = "block";
    }
    else{
        receipt_box.style.display = "none";
    }
}

// 결제하기 버튼
function Order() {

    let upost = document.getElementById("user_postcode").value;
    let uaddr = document.getElementById("user_address").value;
    let usub = document.getElementById("user_subaddress").value;
    let uphone1 = document.getElementById("user_phone1").value;
    let uphone2 = document.getElementById("user_phone2").value;
    let uphone3 = document.getElementById("user_phone3").value;

    let name = document.getElementById("to_name").value;
    let post = document.getElementById("to_postcode").value;
    let addr = document.getElementById("to_address").value;
    let sub = document.getElementById("to_subaddress").value;
    let phone1 = document.getElementById("to_phone1").value;
    let phone2 = document.getElementById("to_phone2").value;
    let phone3 = document.getElementById("to_phone3").value;

    let memo = document.getElementById("memo").value;
    let price = document.getElementById("RealTotalPrice").value;
    //let dprice = document.getElementById("RealTotalPrice").value;
    let type = document.getElementsByName("cardcash").value;
    let buser = document.getElementById("payer").value;
    let btype = document.getElementsByName("receipt_type").value;
    let bnum = document.getElementById("receipt_phone").value;

    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE) {
        var result = JSON.parse(xhr.responseText);
            if (xhr.status === 200 || xhr.status === 201) 
            {  
             
              



                //sucess 
   
               
            } else {

                //error
            }
        }
    }
    xhr.open("POST", "http://13.209.181.48:3000/order");
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("_id=" + sessionStorage.getItem('id_con') + "&_upost=" + upost + "&_uaddr=" + uaddr + "&_usub=" + usub + "&_uphone=" + uphone1 + "-" + uphone2 + "-" + uphone3 +
                "&_name=" + name + "&_post=" + post + "&_addr=" + addr + "&_sub=" + sub + "&_phone=" + phone1 + "-" + phone2 + "-" + phone3 +
                "&_memo=" + memo + "&_price=" + price + "&_dprice=3000" + "&_type=" + type + "&_buser=" +  buser + "&_btype=" + btype + "&_bnum=" + bnum +"&_carts="+cids);

}