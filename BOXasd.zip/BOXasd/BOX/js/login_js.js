var name_user;
var id_const;
var pass_const;

function user_login() {
    var id = document.getElementById("login_id");   //!< 아이디 INPUT에서 데이터 넘겨주시면 됩니다.
    var pass = document.getElementById("login_password");; //!< 비밀번호 INPUT에서 데이터 넘겨주시면 됩니다.
    var element = document.getElementById("fail");
    var xhr = new XMLHttpRequest();
    id_const = id;
    pass_const = pass;
    console.log(id.value + " " + pass.value);
    xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE) {
        var result = JSON.parse(xhr.responseText);
            if (xhr.status === 200 || xhr.status === 201) 
            {
                if(result.result == "failed")
                {
                    element.innerHTML = "아이디와 비밀번호를 다시 확인해주세요."
                }else{
                    
                    sessionStorage.setItem('name', result[0].user_name);
                    sessionStorage.setItem('pass_con', pass.value);
                    sessionStorage.setItem('id_con', id.value);
                    name_user = sessionStorage.getItem('name');
                    location.href='home_login.html';
                    console.log(name_user);
                }
            } else {
                alert("로그인에 실패하였습니다.");
            }
        }
    }

    xhr.open("POST", "http://13.209.181.48:3000/user/login");
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhr.send("_id="+id.value+"&_pass="+pass.value);
}


function user_idcheck() {
    var id2 = document.getElementById("login_id_check");   //!< 아이디 INPUT에서 데이터 넘겨주시면 됩니다
    var regEmail = /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i;
    var xhr = new XMLHttpRequest();
    if(regEmail.test(id2.value))
    {
        xhr.onreadystatechange = function () {
            if (xhr.readyState === xhr.DONE) {
                var result = JSON.parse(xhr.responseText);
                    if (xhr.status === 200 || xhr.status === 201) 
                    {
                        if(result.result == "failed")
                        {
                           alert("중복된 아이디가 존재합니다.");
                        }
                        else{
                            alert("아이디 사용이 가능합니다.");
                        }
                    } else {
                        alert("아이디 확인에 실패하였습니다.");
                    }
                }
            }
    }
    else
    {
        alert("아이디가 형식에 맞지 않습니다.");
        document.getElementById("login_id_check").focus();
    }

    xhr.open("POST", "http://13.209.181.48:3000/user/check");
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("_id="+id2.value);
    
}
function doDisplay(){
    var con1 = document.getElementById("MyInfo");
    var con2 = document.getElementById("MyInfo_line");
    if(con1.style.display=='none'){
       con1.style.display = 'block';
       con2.style.display = 'block';
    }else{
       con1.style.display = 'none';
       con2.style.display = 'none';
    }
 }
function change_id()
{

   var element2 = document.getElementById("login_name");
   //element2.innerText(name_user);
   element2.innerText = sessionStorage.getItem("name");
}



function join_agree(){
    var check_1 = document.getElementById("check1").checked;
    if(check_1 == true)
    {
    document.getElementById("check2").checked = true;
    document.getElementById("check3").checked = true;
    document.getElementById("check4").checked = true;
    }
    else
    {
        
    document.getElementById("check2").checked = false;
    document.getElementById("check3").checked = false;
    document.getElementById("check4").checked = false;
    }
}
function user_apply() {
    var id = document.getElementById("login_id_check");   //!< 아이디 INPUT에서 데이터 넘겨주시면 됩니다
    var pass = document.getElementById("password_first"); //!< 비밀번호 INPUT에서 데이터 넘겨주시면 됩니다.
    var pass2 = document.getElementById("password_second");
    var name = document.getElementById("user_name"); //!< 이름 INPUT에서 데이터 넘겨주시면 됩니다.
    var check_1 = document.getElementById("check1").checked;
    var check_2 = document.getElementById("check2").checked;
    var check_3 = document.getElementById("check3").checked;
    var check_4 = document.getElementById("check4").checked;
    
    if(check_2 == true && check_3 == true)
    {
        console.log(pass.value + " " + pass2.value);
        if(pass.value != pass2.value)
        {
            alert("비밀번호가 일치하지 않습니다.");
        }
        else
        {
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
            if (xhr.readyState === xhr.DONE) {
                var result = JSON.parse(xhr.responseText);
                    if (xhr.status === 200 || xhr.status === 201) 
                    {
                        if(result.result == "failed")
                        {
                            alert("회원가입에 실패하였습니다.");
                        }
                        else{
                            location.href='join_complete.html';
                        }
                    } else {
                        alert("회원가입에 실패하였습니다.");
                    }
                }
            }
        }
        xhr.open("POST", "http://13.209.181.48:3000/user/apply");
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.send("_id="+id.value+"&_pass="+pass.value+"&_name="+name.value);
    }
    else
    {
        alert("약관에 모두 동의하지 않았습니다.");
    }
}
//비밀번호 변경 값 물어보기
function pass_change()
{
    var now_pass = document.getElementById("current_password");
    var pass_1 = document.getElementById("new_password"); //!< 비밀번호 INPUT에서 데이터 넘겨주시면 됩니다.
    var pass_2 = document.getElementById("new_password_check"); 
    if(now_pass.value == sessionStorage.getItem('pass_con'))
    {
        if(pass_1.value == pass_2.value)
        {
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
            if (xhr.readyState === xhr.DONE) {
                var result = JSON.parse(xhr.responseText);
                    if (xhr.status === 200 || xhr.status === 201) 
                    {
                        if(result.result == "failed")
                        {
                            alert("비밀번호 변경에 실패하였습니다.");
                        }
                        else{
                            alert("비밀번호 변경이 완료되었습니다.");
                            //location.href='password_change_complete.html';
                        }
                    } else {
                        alert("비밀번호 변경에 실패하였습니다.");
                    }
                }
            }
        }
        else
        {
            
            alert("재설정 비밀번호가 일치하지 않습니다.");
        }
    }
    else{
        alert("현재 비밀번호가 일치하지 않습니다.");
    }
    xhr.open("POST", "http://13.209.181.48:3000/user/modify/pass");
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("_id="+sessionStorage.getItem('id_con')+"&_pass="+pass_1.value+"&_name="+sessionStorage.getItem("name"));
}

function pass_find()
{
    var name = document.getElementById("user_name");
    var id = document.getElementById("user_id"); 
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === xhr.DONE) {
            var result = JSON.parse(xhr.responseText);
                if (xhr.status === 200 || xhr.status === 201) 
                {
                    if(result.result == "failed")
                    {
                        alert("이메일 보내기에 실패했습니다.");
                    }else{
                        alert("이메일 보내기에 임시비밀번호가 발급되었습니다.");
                        location.href='index.html';
                    }
                } else {
                    alert("비밀번호 찾기에 실패하였습니다.");
                }
            }
        }
    xhr.open("POST", "http://13.209.181.48:3000/user/modify/pass");
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("_id="+id.value+"&_name="+name.value);
}

