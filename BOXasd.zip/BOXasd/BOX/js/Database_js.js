function doDisplay(){
    var con1 = document.getElementById("MyInfo");
    var con2 = document.getElementById("MyInfo_line");
    if(con1.style.display=='none'){
        con1.style.display = 'block';
        con2.style.display = 'block';
    }else{
        con1.style.display = 'none';
        con2.style.display = 'none';
    }
}
function doMessage(){
    var step1 = document.getElementById("present");
    var step2 = document.getElementById("message");
    var step3 = document.getElementById("complete");
    var circle1 = document.getElementsByName("circle1");
    var circle2 = document.getElementsByName("circle2");
    var circle3 = document.getElementsByName("circle3");

    if(step2.style.display=='none'){
        step1.style.display = "none";
        step2.style.display = "block";
        step3.style.display = "none";
        circle1.style.fill = "white";
        circle2.style.fill = "black";
        circle3.style.fill = "white";
    }
    else {
        console.log("In!");
        step1.style.display = "none";
        step2.style.display = "block";
        step3.style.display = "none";
        circle1.style.fill = "white";
        circle2.style.fill = "black";
        circle3.style.fill = "white";
    }
}

function cart_apply(){
    var total_price = 9000;
    var items_id = "";
    
    for(i = 1; i < document.getElementById("layout1_3_1").childNodes.length; i++)
    {
        total_price += Number(document.getElementById("layout1_3_1").childNodes[i].childNodes[2].textContent.replace("원",""));
        items_id += document.getElementById("layout1_3_1").childNodes[i].id.replace("text", "");
        if(i< document.getElementById("layout1_3_1").childNodes.length -1)
        {

            items_id += ",";
        }
    }
    console.log(items_id);
    console.log(total_price);
    sessionStorage.getItem('id_con');
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE) {
        var result = JSON.parse(xhr.responseText);
            if (xhr.status === 200 || xhr.status === 201) 
            {
                console.log(result.result);
            } else {
            }
        }
    }
    xhr.open("POST", "http://13.209.181.48:3000/cart/apply");
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhr.send("_id="+sessionStorage.getItem('id_con')+ "&_name=Build A Box" + "&_sub=White M" + "&_total=" + total_price + "&_card=0" + "&_from= " + "&_to= " + "&_msg= " + "&_items=" + items_id);
}

function doComplete(){
    var step1 = document.getElementById("present");
    var step2 = document.getElementById("message");
    var step3 = document.getElementById("complete");
    var circle1 = document.getElementsByName("circle1");
    var circle2 = document.getElementsByName("circle2");
    var circle3 = document.getElementsByName("circle3");

    if(step3.style.display=='none'){
        step1.style.display = "none";
        step2.style.display = "none";
        step3.style.display = "block";
        circle1.style.fill = "white";
        circle2.style.fill = "white";
        circle3.style.fill = "black";
    }
    else {
        step1.style.display = "none";
        step2.style.display = "none";
        step3.style.display = "block";
        circle1.style.fill = "white";
        circle2.style.fill = "white";
        circle3.style.fill = "black";
    }
}
function doPresent(){
    var step1 = document.getElementById("present");
    var step2 = document.getElementById("message");
    var step3 = document.getElementById("complete");
    var circle1 = document.getElementsByName("circle1");
    var circle2 = document.getElementsByName("circle2");
    var circle3 = document.getElementsByName("circle3");

    if(step1.style.display=='none'){
        step1.style.display = "block";
        step2.style.display = "none";
        step3.style.display = "none";
        circle1.style.fill = "black";
        circle2.style.fill = "white";
        circle3.style.fill = "white";
    }
    else {
        step1.style.display = "block";
        step2.style.display = "none";
        step3.style.display = "none";
        circle1.style.fill = "black";
        circle2.style.fill = "white";
        circle3.style.fill = "white";
    }
}


function cart_click()
{

    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE) {
        var result = JSON.parse(xhr.responseText);
            if (xhr.status === 200 || xhr.status === 201) 
            {
            } else {
            }
        }
    }
    xhr.open("GET", "http://13.209.181.48:3000/color/list");
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhr.send();
}

function category() {
    var category_list = [];
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE) {
        var result = JSON.parse(xhr.responseText);
            if (xhr.status === 200 || xhr.status === 201) 
            {
                for(let a = 0; a<result.length; a++)
                {
                    category_list[a] = document.createElement("option");
                    category_list[a].value = result[a]._category;
                    category_list[a].innerHTML = result[a]._category;
                    document.getElementById("thema").appendChild(category_list[a]);
                    
                }

            } else {
            }
        }
    }
    xhr.open("GET", "http://13.209.181.48:3000/category/list");
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhr.send();
}

function select_category(){
    const type = document.getElementById("thema").value;

    const present = document.getElementById("layout1_5"); while ( present.hasChildNodes() ) { present.removeChild( present.firstChild ); }

    var total_price = 9000;
    for(let i = 1; i < document.getElementById("layout1_3_1").childNodes.length; i++)
    {
        total_price += Number(document.getElementById("layout1_3_1").childNodes[i].childNodes[2].textContent.replace("원",""));
    }
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE) {
        var result = JSON.parse(xhr.responseText);
            if (xhr.status === 200 || xhr.status === 201) 
            {
                var item = [];
                var thumbnail = [];
                var pro_name = [];
                var pro_brand =[];
                var pro_sp = [];
                var onmouse_button;
                var button_on = [];
                var count_cart = []
                var button_plus = [];
                var button_minus = [];
                var text_button = [];
                var item_small = [];
                var thumbnail_small = [];
            
                var text_item_list = [];
                var text_item_list_name = [];
                var text_item_list_num = [];
                var text_item_list_sp = [];
                var text_item_list_button = [];
            
                var circle_number = [];
                var circle_number_text = [];
                var thumbnail_inbutton = [];

                for(let a = 0; a<result.length; a++)
                {
                    count_cart[a] = 0;
                    item[a] = document.createElement('div');
                    sessionStorage.setItem('product'+a, result[a].product_id);
                    sessionStorage.setItem('price'+a, result[a].product_sp);
                    onmouse_button = document.createElement("span");
                    item[a].style.display = "inline-grid";
                    thumbnail_inbutton[a] = document.createElement('div');
                    thumbnail[a] = document.createElement('img');
                    pro_brand[a] = document.createElement("span");
                    pro_brand[a].innerHTML = result[a].product_brand;
                    pro_brand[a].className = "brand_name";
                    pro_name[a] = document.createElement("span");
                    pro_name[a].innerHTML = result[a].product_name;
                    pro_name[a].className = "product_name";
                    pro_sp[a] = document.createElement("span");
                    pro_sp[a].innerHTML = result[a].product_sp + "원";
                    pro_sp[a].className = "product_sp";
                    thumbnail[a].id = "imagid"+a;
                    thumbnail[a].setAttribute("class", "thumbnail");
                    thumbnail[a].src = result[a].product_thumbnail;
                    if(document.getElementById(result[a].product_id + "small"))
                    {
                        var number_temp = document.getElementById(result[a].product_id + "small").lastChild.firstChild.innerText.replace("x","");
                        count_cart[a] = number_temp;
                        var number_temp = document.getElementById(result[a].product_id + "small").lastChild.firstChild.innerText.replace("x","");
                        button_on[a] =  document.createElement("div");
                        button_on[a].id = "button_id"+a;
                        text_button[a] = document.createElement('div');
                        text_button[a].innerHTML = number_temp + "개 담기";
                        text_button[a].className = "text_button";
                        button_on[a].className = "cart_button";
                        button_plus[a] = document.createElement("span");
                        button_plus[a].innerHTML = "+";
                        button_plus[a].className="button_pl";
                        button_minus[a] = document.createElement("span");
                        button_minus[a].innerHTML = "-";
                        button_minus[a].className = "button_mi";
                        button_on[a].appendChild(text_button[a]);
                        thumbnail_inbutton[a].appendChild(thumbnail[a]);
                        thumbnail_inbutton[a].appendChild(button_on[a]);
                        thumbnail_inbutton[a].style.height = 270 + "px";
                        button_on[a].appendChild(button_plus[a]);
                        button_on[a].appendChild(button_minus[a]);
                        item_small[a] =  document.getElementById(result[a].product_id + "small");
                        thumbnail_small[a] = document.getElementById(result[a].product_id + "small").firstChild;
                        circle_number_text[a] = document.getElementById(result[a].product_id + "small").lastChild.firstChild;
                        var price =  Number(count_cart[a]) * sessionStorage.getItem('price'+a).replace(",","");
                        const text_child = document.getElementById(result[a].product_id + "text"); 
                        text_item_list[a] = document.getElementById(result[a].product_id + "text");
                        text_item_list_name[a] =text_child.childNodes[0];
                        text_item_list_num[a] = text_child.childNodes[1];
                        text_item_list_sp[a] = text_child.childNodes[2];
                        text_item_list_button[a] = text_child.childNodes[3];
                        text_item_list_num[a].innerHTML = "X" + count_cart[a];
                        text_item_list_sp[a]. innerHTML = price + "원";
                    }
                    else
                    {
                        button_on[a] =  document.createElement("div");
                        button_on[a].id = "button_id"+a;
                        text_button[a] = document.createElement('div');
                        text_button[a].innerHTML = "박스에 담기";
                        text_button[a].className = "text_button";
                        button_on[a].className = "cart_button";
                        button_plus[a] = document.createElement("span");
                        button_plus[a].innerHTML = "+";
                        button_plus[a].className="button_pl";
                        button_minus[a] = document.createElement("span");
                        button_minus[a].innerHTML = "-";
                        button_minus[a].className = "button_mi";
                        button_on[a].appendChild(text_button[a]);
                        thumbnail_inbutton[a].appendChild(thumbnail[a]);
                        thumbnail_inbutton[a].appendChild(button_on[a]);
                        thumbnail_inbutton[a].style.height = 270 + "px";
                    }
                    button_plus[a].onclick = function(){
                    count_cart[a]++;
                    text_button[a].innerHTML = count_cart[a]+"개 담기";
                    var price =  Number(count_cart[a]) * sessionStorage.getItem('price'+a).replace(",","");
                    circle_number_text[a].innerHTML = "x" + count_cart[a];
                    text_item_list_num[a].innerHTML = "X" + count_cart[a];
                    text_item_list_sp[a]. innerHTML = price + "원";
                    
                    total_price += Number(sessionStorage.getItem('price'+a).replace(",",""));
                    document.getElementById("TotalPrice").innerHTML = total_price+"원";
                    }
                    var temp = true;
                    button_minus[a].onclick = function(){
                        if(count_cart[a] == 1)
                        {
                            temp = false;
                            button_on[a].removeChild(button_plus[a]);
                            button_on[a].removeChild(button_minus[a]);
                            item_small[a].removeChild(thumbnail_small[a]);
                            document.getElementById("layout1_3_1").removeChild(text_item_list[a]);
                            document.getElementById("layout1_2").removeChild(item_small[a]);
                            text_button[a].innerHTML = "박스에 담기";
                            count_cart[a]--;
                            total_price -= Number(sessionStorage.getItem('price'+a).replace(",",""));
                            document.getElementById("TotalPrice").innerHTML = total_price+"원";
                            setTimeout(function() {
                                temp = true;
                            }, 500);
                        }
                        else
                        {
                            count_cart[a]--;
                            text_button[a].innerHTML = count_cart[a]+"개 담기";
                            var price =  Number(count_cart[a]) * sessionStorage.getItem('price'+a).replace(",","");
                            circle_number_text[a].innerHTML = "x" + count_cart[a];
                            text_item_list_num[a].innerHTML = "X" + count_cart[a];
                            text_item_list_sp[a]. innerHTML = price + "원";
                            
                            total_price -= Number(sessionStorage.getItem('price'+a).replace(",",""));
                            document.getElementById("TotalPrice").innerHTML = total_price+"원";
                            
                        }
                    }
                    button_on[a].onclick = function(){
                        if(count_cart[a] == 0 && temp == true)
                        {
                            count_cart[a]++;
                            if(document.getElementById(result[a].product_id + "small"))
                            {
                                var number_temp = document.getElementById(result[a].product_id + "small").lastChild.firstChild.innerText.replace("x","");
                                count_cart[a] = number_temp;
                                count_cart[a]++;
                                circle_number[a] = document.getElementById(result[a].product_id + "small").lastChild;
                                circle_number_text[a] = document.getElementById(result[a].product_id + "small").lastChild.firstChild;
                                circle_number_text[a].innerHTML = "x" + count_cart[a];
                                item_small[a] =  document.getElementById(result[a].product_id + "small");
                                thumbnail_small[a] = document.getElementById(result[a].product_id + "small").firstChild;
                                
                                total_price += Number(sessionStorage.getItem('price'+a).replace(",",""));
                                document.getElementById("TotalPrice").innerHTML = total_price+"원";
                            }
                            else
                            {
                                circle_number[a] = document.createElement('div');
                                circle_number_text[a] = document.createElement('div');
                                circle_number_text[a].innerHTML = "x" + count_cart[a];
                                circle_number_text[a].className = "circle_num_text";
                                circle_number[a].className = "circle_num";
                                circle_number[a].appendChild(circle_number_text[a]);
                                item_small[a] =  document.createElement('div');
                                item_small[a].id = result[a].product_id + "small";
                                item_small[a].style.display = "inline-grid";
                                thumbnail_small[a] = document.createElement('img');
                                thumbnail_small[a].setAttribute("class", "thumbnail_small");
                                thumbnail_small[a].src = result[a].product_thumbnail;
                                item_small[a].appendChild(thumbnail_small[a]);
                                item_small[a].appendChild(circle_number[a]);
                                button_on[a].appendChild(button_plus[a]);
                                button_on[a].appendChild(button_minus[a]);
                                
                                total_price += Number(sessionStorage.getItem('price'+a).replace(",",""));
                                document.getElementById("TotalPrice").innerHTML = total_price+"원";
                            }
                                
                            text_button[a].innerHTML = count_cart[a]+"개 담기";
                                
                                
                            text_item_list[a] = document.createElement('div');
                            text_item_list[a].id = result[a].product_id + "text";
                            text_item_list_name[a] = document.createElement('div');
                            text_item_list_num[a] = document.createElement('div');
                            text_item_list_sp[a] = document.createElement('div');
                            text_item_list_button[a] = document.createElement('div');

                            text_item_list[a].className = "text_item_list";
                            text_item_list_name[a].className = "text_item_list_name";
                            text_item_list_num[a].className = "text_item_list_num";
                            text_item_list_sp[a].className = "text_item_list_sp";
                            text_item_list_button[a].className = "text_item_list_button";
                            text_item_list_name[a].innerHTML = "[" + result[a].product_brand + "]" + " " + result[a].product_name;
                            text_item_list_num[a].innerHTML = "X" + count_cart[a];
                            //var new_price = Number(sessionStorage.getItem('price'+a));
                            var price =  Number(count_cart[a]) * sessionStorage.getItem('price'+a).replace(",","");
                            text_item_list_sp[a].innerHTML = price + "원";
                            console.log(count_cart[a] + " " + sessionStorage.getItem('price'+a));
                            text_item_list_button[a]. innerHTML = "X";
                            text_item_list[a].appendChild(text_item_list_name[a]);
                            text_item_list[a].appendChild(text_item_list_num[a]);
                            text_item_list[a].appendChild(text_item_list_sp[a]);
                            text_item_list[a].appendChild(text_item_list_button[a]);
                            document.getElementById("layout1_3_1").appendChild(text_item_list[a]);
                            document.getElementById("layout1_2").appendChild(item_small[a]);
                        }
                    }
                    item[a].appendChild(thumbnail_inbutton[a]);
                    item[a].appendChild(pro_brand[a]);
                    item[a].appendChild(pro_name[a]);
                    item[a].appendChild(pro_sp[a]);
                    document.getElementById("layout1_5").appendChild(item[a]);
                    item[a].onmouseenter=function(){
                        button_on[a].style.visibility = "visible";
                    }
                    item[a].onmouseleave=function(){
                        button_on[a].style.visibility = "hidden";
                    }

                }
            } else {
            }
        }
    }
    if(type == "none")
    {
        xhr.open("GET", "http://13.209.181.48:3000/product/list");
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.send();
    }
    else
    {
        xhr.open("POST", "http://13.209.181.48:3000/product/list/category");
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	    xhr.send("_category=" + document.getElementById("thema").value);
    }
}

function color() {
    var color_list = [];
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE) {
        var result = JSON.parse(xhr.responseText);
            if (xhr.status === 200 || xhr.status === 201) 
            {
                for(let a = 0; a<result.length; a++)
                {
                    color_list[a] = document.createElement("option");
                    color_list[a].innerHTML = result[a]._color;
                    document.getElementById("color_li").appendChild(color_list[a]);
                }
            } else {
            }
        }
    }
    xhr.open("GET", "http://13.209.181.48:3000/color/list");
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhr.send();
}